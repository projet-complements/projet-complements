echo"
    DNA_2_BINARY.sh - written by Abhijeet Singh (abhijeetsingh.aau@gmail.com)
    Translating DNA bases to 0 and 1
"


if [ "$#" -gt 0 ]; then
	filename=$1
else
	echo "please provide the name of your fasta file"
	read filename
fi
fasta_file=filename
cut -d ' ' -f1 "${!fasta_file}" > "${!fasta_file}"_trimhead
awk 'BEGIN{RS=">"}NR>1{sub("\n","\t"); gsub("\n",""); print RS$0}' "${!fasta_file}"_trimhead > "${!fasta_file}"_tab
awk '{print $1}' < "${!fasta_file}"_tab > "${!fasta_file}"_tab_col1
awk '{print $2}' < "${!fasta_file}"_tab > "${!fasta_file}"_tab_col2
echo "
-----------------------------------
The codes used for translation are:
-=0; A=1; B=2; C=3; D=4; E=5; F=6; G=7; H=8; I=9; J=27; K=10; L=11; M=12; N=13; O=26; P=14; Q=15; R=16; S=17; T=18; U=24; V=19; W=20; X=21; Y=22; Z=23; *=25;
-----------------------------------"
sed 's/-/0/g;s/A/1/g;s/B/2/g;s/C/3/g;s/D/4/g;s/E/5/g;s/F/6/g;s/G/7/g;s/H/8/g;s/I/9/g;s/J/27/g;s/K/10/g;s/L/11/g;s/M/12/g;s/N/13/g;s/O/26/g;s/P/14/g;s/Q/15/g;s/R/16/g;s/S/17/g;s/T/18/g;s/U/24/g;s/V/19/g;s/W/20/g;s/X/21/g;s/Y/22/g;s/Z/23/g;s/*/25/g' "${!fasta_file}"_tab_col2 > "${!fasta_file}"_tab_col2_2
paste "${!fasta_file}"_tab_col1 "${!fasta_file}"_tab_col2_2 | column -s $'\n' -t > "${!fasta_file}"_binary.tmp.txt
sed 's/\t/\n/g' < "${!fasta_file}"_binary.tmp.txt > "${!fasta_file}"_binary.txt
rm -f "${!fasta_file}"{_trimhead,_tab,_tab_col1,_tab_col2,_tab_col2_2,_binary.tmp.txt}
echo "                            ========================="
echo "your result file is ---->>> ${!fasta_file}_binary.txt"
echo "                            ========================="

